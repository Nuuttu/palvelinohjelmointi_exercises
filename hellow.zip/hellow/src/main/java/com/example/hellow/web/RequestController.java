package com.example.hellow.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@ResponseBody
public class RequestController {
	@RequestMapping("/hello")
	public String hello(@RequestParam(name="firstname", required=false, defaultValue="(firstname)")String firstname, 
			@RequestParam(name="location", required=false, defaultValue="(location)")String location) {
		return "Hello " + firstname + " " + location;
	}
}